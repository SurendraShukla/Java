import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

/**
 * Created by pasarkag on 3/2/16.
 */
public class RoundTest {

    @Mock private Choice player1Choice;
    @Mock private Choice player2Choice;

    private Round r = new Round();

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void outcomeShouldBePlayer1IfPlayer1CanBeatPlayer2() throws Exception {
        Mockito.when(player1Choice.canBeat(player2Choice)).thenReturn(true);
        Assert.assertEquals(Outcome.PLAYER1, r.play(player1Choice, player2Choice));
    }

    @Test
    public void outcomeShouldBePlayer2IfPlayer1CannotBeatPlayer2() throws Exception {
        Mockito.when(player1Choice.canBeat(player2Choice)).thenReturn(false);
        Assert.assertEquals(Outcome.PLAYER2, r.play(player1Choice, player2Choice));
    }

    @Test
    public void outcomeShouldBeDrawIfBothChoicesAreSame() throws Exception {
        Assert.assertEquals(Outcome.DRAW, r.play(player1Choice, player1Choice));
    }
}