import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

/**
 * Created by pasarkag on 3/2/16.
 */
public class GameTest {
    @Mock Round round;

    private Game unit;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        unit = new Game(round);
    }

    @Test
    public void shouldCompleteGameWhenPlayer1Wins3Times() throws Exception {
        Mockito.when(round.play(Mockito.any(Choice.class), Mockito.any(Choice.class)))
                .thenReturn(Outcome.PLAYER1);
        unit.start();

        Assert.assertEquals(3, unit.roundsPlayed);
    }

    @Test
    public void shouldCompleteGameWhenPlayer2Wins3Times() throws Exception {
        Mockito.when(round.play(Mockito.any(Choice.class), Mockito.any(Choice.class)))
                .thenReturn(Outcome.PLAYER2);
        unit.start();

        Assert.assertEquals(3, unit.roundsPlayed);
    }
}