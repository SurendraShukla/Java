import org.junit.Assert;
import org.junit.Test;

/**
 * Created by pasarkag on 3/3/16.
 */
public class ChoiceTest {
    @Test
    public void testRockShouldBeatScissor() throws Exception {
        Assert.assertTrue(Choice.ROCK.canBeat(Choice.SCISSOR));
    }

    @Test
    public void testScissorShouldNotBeatRock() throws Exception {
        Assert.assertFalse(Choice.SCISSOR.canBeat(Choice.ROCK));
    }

    @Test
    public void testPaperShouldBeatRock() throws Exception {
        Assert.assertTrue(Choice.PAPER.canBeat(Choice.ROCK));
    }

    @Test
    public void testRockShouldNotBeatPaper() throws Exception {
        Assert.assertFalse(Choice.ROCK.canBeat(Choice.PAPER));
    }

    @Test
    public void testScissorShouldBeatPaper() throws Exception {
        Assert.assertTrue(Choice.SCISSOR.canBeat(Choice.PAPER));
    }

    @Test
    public void testPaperShouldNotBeatScissor() throws Exception {
        Assert.assertFalse(Choice.PAPER.canBeat(Choice.SCISSOR));
    }
}