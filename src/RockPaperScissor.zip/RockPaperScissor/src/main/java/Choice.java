/**
 * Created by pasarkag on 3/2/16.
 */
public enum Choice {
    ROCK {
        @Override
        public boolean canBeat(Choice choice) {
            return choice.equals(SCISSOR);
        }
    },
    PAPER {
        @Override
        public boolean canBeat(Choice choice) {
            return choice.equals(ROCK);
        }
    },
    SCISSOR {
        @Override
        public boolean canBeat(Choice choice) {
            return choice.equals(PAPER);
        }
    };

    public abstract boolean canBeat(Choice choice);

    public static Choice randomChoice() {
        int c = (int)(Math.random()*3);
        return Choice.values()[c];
    }
}
