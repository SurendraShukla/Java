/**
 * Created by pasarkag on 3/3/16.
 */
public enum Outcome {
    PLAYER1 {
        @Override
        public void printOutput() {
            System.out.println("Player 1 Wins");
        }
    },
    PLAYER2 {
        @Override
        public void printOutput() {
            System.out.println("Player 2 Wins");
        }
    },
    DRAW {
        @Override
        public void printOutput() {
            System.out.println("      DRAW     ");
        }
    };

    public abstract void printOutput();
}
