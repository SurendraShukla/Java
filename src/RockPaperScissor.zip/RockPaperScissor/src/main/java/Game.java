import java.util.EnumMap;

/**
 * Simulate a game of Rock, Paper, Scissors
 */
public class Game {

    public int roundsPlayed = 0;    // Number of rounds played
    private EnumMap<Outcome, Integer> scores = new EnumMap<Outcome, Integer>(Outcome.class);
    private Round round;
    private boolean gameWon = false;

    public Game(Round round) {
        this.round = round;
        scores.put(Outcome.PLAYER1, 0);
        scores.put(Outcome.PLAYER2, 0);
        scores.put(Outcome.DRAW, 0);
    }

    public void start() {
        do {
            System.out.println("***** Round: " +
                    roundsPlayed + " *********************\n");
            playRound();
            roundsPlayed++;
            displayRoundStats();
            markGameCompleteIfCompleted();
        } while(canPlayNextRound());
    }

    private boolean canPlayNextRound() {
        return gameWon != true;
    }

    private void markGameCompleteIfCompleted() {
        if(isGameComplete()) {
            gameWon = true;
            System.out.println("GAME WON");
        }
        System.out.println();
    }

    private void playRound() {
        final Outcome outcome = round.play(Choice.randomChoice(), Choice.randomChoice());
        outcome.printOutput();
        scores.put(outcome, scores.get(outcome) + 1);
    }

    private boolean isGameComplete() {
        return (player1Wins()>=3) || (player2Wins()>=3);
    }

    private void displayRoundStats() {
        System.out.println("Player 1 Total Wins: " + player1Wins());
        System.out.println("Player 2 Total Wins: " + player2Wins());
        System.out.println("Number of Draws: "+ draws() + "\n");
    }

    private Integer player1Wins() {
        return scores.get(Outcome.PLAYER1);
    }

    private Integer player2Wins() {
        return scores.get(Outcome.PLAYER2);
    }

    private Integer draws() {
        return scores.get(Outcome.DRAW);
    }

    public static void main(String args[])
    {
         new Game(new Round()).start();
    }
}