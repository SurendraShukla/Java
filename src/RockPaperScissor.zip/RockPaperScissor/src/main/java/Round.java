/**
 * Created by pasarkag on 3/2/16.
 */
public class Round {

    public Outcome play(Choice p1Choice, Choice p2Choice) {
        System.out.println("Player 1: " + p1Choice);
        System.out.println("Player 2: " + p2Choice);

        if(p1Choice==p2Choice) {
           return Outcome.DRAW;
        } else if (p1Choice.canBeat(p2Choice)) {
           return Outcome.PLAYER1;
        } else {
           return Outcome.PLAYER2;
        }
    }
}
